/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unicauca.pagos.p.plugin.bch;

import co.edu.unicauca.pagos.p.common.Pago;

/**
 *
 * @author Katherine
 */
public class PagoTransferenciaBancaria implements Pago{
    private String cuentaBancaria;
    private double monto;

    public PagoTransferenciaBancaria(String cuentaBancaria, double monto) {
        this.cuentaBancaria = cuentaBancaria;
        this.monto = monto;
    }

    public boolean validar() {
        return cuentaBancaria != null && cuentaBancaria.length() == 10;
    }

    public void procesar() {
        if (validar()) {
            System.out.println("Transferencia bancaria procesada: " + monto);
        } else {
            System.out.println("Número de cuenta inválido.");
        }
    }

    public String obtenerDetalle() {
        return "Pago por transferencia bancaria - Monto: " + monto;
    }
}
