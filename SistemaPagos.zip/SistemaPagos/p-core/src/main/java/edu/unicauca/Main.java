/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.unicauca;

import co.edu.unicauca.pagos.p.common.Pago;
import co.edu.unicauca.pagos.p.core.ProcesadorPagos;
import co.edu.unicauca.pagos.p.plugin.bch.PagoCriptomoneda;
import co.edu.unicauca.pagos.p.plugin.bch.PagoTarjetaCredito;
import co.edu.unicauca.pagos.p.plugin.bch.PagoTransferenciaBancaria;




/**
 *
 * @author Katherine
 */
public class Main {
     public static void main(String[] args) {
        ProcesadorPagos procesador = new ProcesadorPagos();

        Pago pago1 = new PagoTarjetaCredito("1234567812345678", 150.0);
        Pago pago2 = new PagoTransferenciaBancaria("1234567890", 200.0);
        Pago pago3 = new PagoCriptomoneda("0x123abc456def", 300.0);

        procesador.procesarPago(pago1);
        procesador.procesarPago(pago2);
        procesador.procesarPago(pago3);
    }
}
